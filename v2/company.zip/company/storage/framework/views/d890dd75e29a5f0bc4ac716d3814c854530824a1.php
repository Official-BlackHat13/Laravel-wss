<?php $gst = str_replace('/public','',url('/uploads/')); ?>

<?php $__env->startSection('content'); ?>
<style>
.alert-success {
    color: #fff;
    background: #28a745;
    border-color: #23923d;
    width: 20%;
    float: right;
}
.student-img{
  height: 50px;
  width: 50px;
}
.dropdown-toggle::after {
    display: inline-block;
    margin-left: 0.255em;
    vertical-align: 0.255em;
    content: "";
    border-top: 0.3em solid;
    border-right: 0.3em solid transparent;
    border-bottom: 0;
    border-left: 0.3em solid transparent;
}
</style>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Send Email</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Send Emails</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <?php if(session('msg')): ?>
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h4><i class="fa fa-check-circle"></i> Success</h4> Mail <a href="javascript:void(0)"
                                class="alert-link">Sent!!</a>!
                        </div>
    <?php endif; ?>

    <?php if(session('msg2')): ?>
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h4><i class="fa fa-check-circle"></i>Error</h4> Mail Not <a href="javascript:void(0)"
                                class="alert-link">Sent!!</a>!
                        </div>
    <?php endif; ?>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>SNo</th>
                    <th>Features</th>
                    <th>Action</th>
                    
                  </tr>
                  </thead>
                  <tbody>
                  
                    <tr>
                      <td>1</td>
                      <td>Service Provider</td>
                      <td>
                        <div style="display: flex;">
                          <button class="btn btn-primary btn-sm" id="Service_provider" name="edit" data-toggle="modal" data-target="#exampleModal" onclick="fetchID(this.id)"><i class="fas fa-share-square"></i> Send Email</button>
                        </div>
                      </td>
                    </tr>

                    <tr>
                      <td>2</td>
                      <td>Builder Properties</td>
                      <td>
                        <div style="display: flex;">
                          <button class="btn btn-primary btn-sm" id="Builder_properties" name="edit" data-toggle="modal" data-target="#exampleModal" onclick="fetchID(this.id)"><i class="fas fa-share-square"></i> Send Email</button>
                        </div>
                      </td>
                    </tr>

                    <tr>
                      <td>3</td>
                      <td>Secondary Rental</td>
                      <td>
                        <div style="display: flex;">
                          <button class="btn btn-primary btn-sm" id="Secondary_rental" name="edit" data-toggle="modal" data-target="#exampleModal" onclick="fetchID(this.id)"><i class="fas fa-share-square"></i> Send Email</button>
                        </div>
                      </td>
                    </tr>

                    <tr>
                      <td>4</td>
                      <td>Independent - Secondary Sale</td>
                      <td>
                        <div style="display: flex;">
                          <button class="btn btn-primary btn-sm" id="Independent_secondary_sale" name="edit" data-toggle="modal" data-target="#exampleModal" onclick="fetchID(this.id)"><i class="fas fa-share-square"></i> Send Email</button>
                        </div>
                      </td>
                    </tr>
                    
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Send Email</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               <div class="col-md-12">
                    <form action="<?php echo e(route('sendmail')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Features Name</label>
                            <input type="text" class="form-control" name="name" id="name" value="" readonly>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control" name="email" id="email" placeholder="Enter email">
                        </div>
                        <div class="form-group">
                            <center><button class="btn btn-success" name="submit" type="submit" id="submit"><i class="fas fa-paper-plane"></i> Submit</button>
                            <button class="btn btn-danger" name="reset" type="submit" id="reset"> <i class="fas fa-sync-alt"></i> Reset</button></center>
                        </div>
                    </form>
                </div>
            </div>
            
            </div>
        </div>
    </div>
    
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
function fetchID(id){

// alert(id);
document.getElementById("name").value = id;

}

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/irera/public_html/admin.irera/resources/views/send-email/sendemail.blade.php ENDPATH**/ ?>