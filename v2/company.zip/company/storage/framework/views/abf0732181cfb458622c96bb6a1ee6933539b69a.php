<?php $gst = str_replace('/public','',url('/uploads/')); ?>

<?php $__env->startSection('content'); ?>
<style>
.alert-success {
    color: #fff;
    background: #28a745;
    border-color: #23923d;
    width: 20%;
    float: right;
}
.student-img{
  height: 50px;
  width: 50px;
}
.dropdown-toggle::after {
    display: inline-block;
    margin-left: 0.255em;
    vertical-align: 0.255em;
    content: "";
    border-top: 0.3em solid;
    border-right: 0.3em solid transparent;
    border-bottom: 0;
    border-left: 0.3em solid transparent;
}
</style>
<?php if(Session::has('msg')): ?>
    <p style="z-index: 1;" class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>"><?php echo e(Session::get('msg')); ?> <i class="fas fa-check-circle"></i></p>
<?php endif; ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Courses</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Skill Level</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <button class="btn btn-success btn-sm" style="float: right;"><i class="fas fa-plus"></i> Add Courses</button>
                </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>SNo</th>
                    <th>Name</th>
                    <th>Instructor</th>
                    <th>Topic</th>
                    <th>Duration</th>
                    <th>Image</th>
                    <th>Price</th>
                    <th>Offer Price</th>
                    <th>Discount</th>
                    <th>Ratings</th>
                    <th>Coupon</th>
                    <th>Views</th>
                    <th>Skill Level</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                        $i = 1;
                    ?>
                    <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo $i;?></td>
                        <td><?php echo e($row->course_name); ?></td>
                        <td><?php echo e($row->instructor_id); ?></td>
                        <td><?php echo e($row->topic_id); ?>t</td>
                        <td><?php echo e($row->course_duration); ?> </td>
                        <td><?php echo e($row->image); ?></td>
                        <td><?php echo e($row->price); ?></td>
                        <td><?php echo e($row->offer_price); ?></td>
                        <td><?php echo e($row->discount); ?></td>
                        <td><?php echo e($row->ratings); ?></td>
                        <td><?php echo e($row->coupon_code); ?></td>
                        <td><?php echo e($row->views_count); ?></td>
                        <td><?php echo e($row->skill_level_id); ?></td>
                        <td><?php echo e($row->short_description); ?></td>
                        <td>
                            <?php
                            if($row->status == 1){?>
                                <center><button class="btn btn-success btn-sm" style="padding: 1px 8px;font-size: 12px;line-height: 13px;box-shadow: 2px 4px 5px 0px #484d49d4;">Active &nbsp; <i class="fa fa-check" aria-hidden="true" style="font-size: 9px;"></i></button></center>
                            <?php
                            }else{?>
                                <center><button class="btn btn-danger btn-sm" style="padding: 1px 8px;font-size: 12px;line-height: 13px;box-shadow: 2px 4px 5px 0px #484d49d4;">In-Active &nbsp; <i class="fa fa-times" aria-hidden="true" style="font-size: 9px;"></i></button></center>
                            <?php
                            }
                        ?>
                        </td>
                      <td>
                        <div style="display: flex;">
                            <button class="btn btn-primary btn-sm" id="" name="edit" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-edit"></i> Edit</button> &nbsp;
                            <button class="btn btn-danger btn-sm" id="delete"><i class="fas fa-trash"></i> Delete</button>
                        </div>
                      </td>
                    </tr>
                    <?php
                        $i++;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Send Email</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               <div class="col-md-12">
                    <form action="<?php echo e(route('sendmail')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Features Name</label>
                            <input type="text" class="form-control" name="name" id="name" value="" readonly>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control" name="email" id="email" placeholder="Enter email">
                        </div>
                        <div class="form-group">
                            <center><button class="btn btn-success" name="submit" type="submit" id="submit"><i class="fas fa-paper-plane"></i> Submit</button>
                            <button class="btn btn-danger" name="reset" type="submit" id="reset"> <i class="fas fa-sync-alt"></i> Reset</button></center>
                        </div>
                    </form>
                </div>
            </div>
            
            </div>
        </div>
    </div>
    
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/irera/public_html/admin.irera/resources/views/courses/courses.blade.php ENDPATH**/ ?>