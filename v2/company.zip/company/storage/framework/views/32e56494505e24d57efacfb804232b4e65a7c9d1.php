<?php $gst = 'https://bniindiastore.com/bmongers/uploads/' ?>

<?php $__env->startSection('content'); ?>
<div class="main-content">
   <div class="section__content section__content--p30">
      <div class="container-fluid">
         <div class="row">
            <div class="col-lg-6">
               <div class="card">
                  <div class="card-header">Edit Offer Banner</div>
                  <form method="post" action="<?php echo e(route('update-offer-banner')); ?>"  enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>
                     <div class="card-body">
                        <div class="row">
                           <div class="col-md-12">
                              <label>Location:</label>
                              <select class="form-control" name="location">
                                  <?php //print_r($locationlist);exit; ?>
                                    <?php $__currentLoopData = $locationlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <option value="<?php echo e($row->city); ?>" <?php if($row->city==$editbanner->location){echo 'selected';} ?>><?php echo e($row->city); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                           </div>
                        </div>
                        <br>
                        <div class="row">
                           <div class="col-md-12">
                              <label>image:</label>
                              <input type="file" class="form-control" name="image">
                               <br>
                              <img src="<?php echo e($gst); ?>/<?php echo e($editbanner->image); ?>" style="width:100px;height:60px;">
                           </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-12">
                              <label>Coupon Code:</label>
                              <input type="text" class="form-control" name="coupon_code" value=<?php echo e($editbanner->coupon_code); ?>>
                                
                           </div>
                        </div>
                     </div>
                     <div class="card-footer">
                        <button type="submit" class="btn btn-primary btn-sm">
                        <i class="fa fa-dot-circle-o"></i> Submit
                        </button>
                        <button type="reset" class="btn btn-danger btn-sm">
                        <i class="fa fa-ban"></i> Reset
                        </button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bniindiastore/public_html/bmongers/company/resources/views/offer_banner_from_edit.blade.php ENDPATH**/ ?>