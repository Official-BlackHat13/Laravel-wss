<?php $__env->startSection('content'); ?>

<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <?php if(Session::has('success')): ?>
                <p style="z-index: 1;" class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>"><?php echo e(Session::get('success')); ?> <i class="fas fa-check-circle"></i></p>
            <?php endif; ?>
            <div class="row">
                <button style="margin-bottom:15px;" class="btn btn-danger btn-xs delete-all" id="btnPrintorder">Delete Selected</button>&nbsp;
            </div>   
            <div class="row">
                <div class="col-md-12">
                    <table id="example" class="table table-bordered table-striped table-responsive">
                        <thead>
                            <tr>
                                <th></th>
                                <th>S.No</th>
                                <th>Order Id</th>
                                <th>User Name </th>
                                <th>Mobile</th>
                                <th>Address</th>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Amount</th>
                                <th>Color</th>
                                <th>Size</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $i = 1;
                            ?>
                            <?php $__currentLoopData = $users1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><input type="checkbox" class="chkAccId" value="<?php echo e($row->id); ?>"></td>
                                <td><?php echo $i++;?></td>
                                <td><?php echo e($row->order_id); ?></td>
                                <td><?php echo e($row->u_name); ?></td>
                                <td><?php echo e($row->mobile); ?></td>
                                <td><?php echo e($row->address); ?></td>
                                <td><?php echo e($row->p_name); ?></td>
                                <td><?php echo e($row->qty); ?></td>
                                <td><?php echo e($row->total_amount); ?></td>
                                <td><?php if($row->c_name==''){echo 'N/A';}else{echo $row->c_name;} ?></td>
                                <td><?php if($row->s_name==''){echo 'N/A';}else{echo $row->s_name;} ?></td>
                                <td><?php echo e($row->date); ?></td>
                                <td>
                                    <?php //if($row->status==1){echo 'Processing';}elseif($row->status==2){echo 'Delivered';}elseif($row->status==3){echo 'Return';}elseif($row->status==4){echo 'Cancelled';}else{echo 'On the way';} ?>
                                    <select class="select2" value="" name="Status" autocomplete="off" onchange="ChangeStatus(this.value);">
                                        <option value="<?php echo e($row->id); ?>/1" <?php echo e(($row->status == '1' ? "selected":"")); ?>>Processing</option>
                                        <option value="<?php echo e($row->id); ?>/2" <?php echo e(($row->status == '2' ? "selected":"")); ?>>Delivered</option>
                                        <option value="<?php echo e($row->id); ?>/3" <?php echo e(($row->status == '3' ? "selected":"")); ?>>Return</option>
                                        <option value="<?php echo e($row->id); ?>/4" <?php echo e(($row->status == '4' ? "selected":"")); ?>>Cancelled</option>
                                        <option value="<?php echo e($row->id); ?>/5" <?php echo e(($row->status == '5' ? "selected":"")); ?>>On the way</option>
                                    </select>
                                </td>
                                <td>
                                    <div style="display: flex;">
                                        <a href="<?php echo e(url('delete-order/'.$row->id)); ?>" data-toggle="tooltip" data-placement="top" title="Delete"><button class="btn btn-danger btn-sm" id="delete"><i class="fas fa-trash"></i> </button></a>&nbsp;
                                    </div>
                                </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div> 
            </div> 
        </div> 
    </div> 
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script>
function ChangeStatus(ids){
        var arr = ids.split('/');

        var id = parseInt(arr[0]);
        var status = parseInt(arr[1]);
    $.confirm({
    title: 'Alert!',
    content: 'are you sure to change status',
    type: 'red',
    typeAnimated: true,
    buttons: {
        confirm: function () {
           $.getJSON('<?php echo e(url("updateorderstatus")); ?>', {id:id,status: status}, function (data) {
            location.reload();
        });
        },
        cancel: function () {
            $.alert('Canceled!');
        },
    }
});
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bniindiastore/public_html/bmongers/company/resources/views/orderlist.blade.php ENDPATH**/ ?>