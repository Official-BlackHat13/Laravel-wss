<?php $gst = str_replace('/public','',url('/images/users')); ?>

<?php $__env->startSection('content'); ?>
<style>
.alert-success {
    color: #fff;
    background: #28a745;
    border-color: #23923d;
    width: 20%;
    float: right;
}
.dropdown-toggle::after {
    display: inline-block;
    margin-left: 0.255em;
    vertical-align: 0.255em;
    content: "";
    border-top: 0.3em solid;
    border-right: 0.3em solid transparent;
    border-bottom: 0;
    border-left: 0.3em solid transparent;
}
.instructor-img{
    height: 50px;
    width: 50px;
}
</style>
<?php if(Session::has('msg')): ?>
    <p style="z-index: 1;" class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>"><?php echo e(Session::get('msg')); ?> <i class="fas fa-check-circle"></i></p>
<?php endif; ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!--<section class="content-header">-->
    <!--  <div class="container-fluid">-->
    <!--    <div class="row mb-2">-->
    <!--      <div class="col-sm-6">-->
    <!--        <h1>Instructors</h1>-->
    <!--      </div>-->
    <!--      <div class="col-sm-6">-->
    <!--        <ol class="breadcrumb float-sm-right">-->
    <!--          <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>-->
    <!--          <li class="breadcrumb-item active">Instructors</li>-->
    <!--        </ol>-->
    <!--      </div>-->
    <!--    </div>-->
    <!--  </div><!-- /.container-fluid -->
    <!--</section>-->
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card" style="margin-top: 1rem;">
                <div class="card-header" style="display: flex;">
                    <div class="col-md-6">
                        <h5>ALL INSTRUCTORS</h5>
                    </div>
                    <div class="col-md-6">
                        <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModal" style="float: right;"><i class="fas fa-plus"></i> Add Instructor</button>
                    </div>
                </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>SNo</th>
                    <th>Name</th>
                    <th>Image</th>
                    <th>Total Courses</th>
                    <th>Ratings</th>
                    <!--<th>Description</th>-->
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                        $i = 1;
                    ?>
                    <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo $i;?></td>
                      <td><?php echo e($row->name); ?></td>
                      <td><img src="<?php echo e($gst); ?>/<?php echo e($row->image); ?>" alt="instructor" class="img-fluid instructor-img"></td>
                      <td><?php echo e($row->total_courses); ?></td>
                      <td><?php echo e($row->ratings); ?></td>
                      <!--<td><?php echo e($row->descriptions); ?></td>-->
                      <td>
                          <?php
                            if($row->status == 1){?>
                                <center><button class="btn btn-success btn-sm" style="padding: 1px 8px;font-size: 12px;line-height: 13px;box-shadow: 2px 4px 5px 0px #484d49d4;">Active &nbsp; <i class="fa fa-check" aria-hidden="true" style="font-size: 9px;"></i></button></center>
                            <?php
                            }else{?>
                                <center><button class="btn btn-danger btn-sm" style="padding: 1px 8px;font-size: 12px;line-height: 13px;box-shadow: 2px 4px 5px 0px #484d49d4;">In-Active &nbsp; <i class="fa fa-times" aria-hidden="true" style="font-size: 9px;"></i></button></center>
                            <?php
                            }
                        ?>
                      </td>
                      <td>
                        <div style="display: flex;">
                            <button class="btn btn-primary btn-sm edit_id" id="<?php echo e($row->id); ?>" name="edit"><i class="fas fa-edit"></i> Edit</button> &nbsp;
                            <button class="btn btn-danger btn-sm" id="delete"><i class="fas fa-trash"></i> Delete</button>
                        </div>
                      </td>
                    </tr>
                    <?php
                        $i++;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!--ADD Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Instructor</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               <div class="col-md-12">
                    <form method="post" action="javascript:;" id="add_instructor_form" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <label>Instructor Name</label>
                                <input type="text" class="form-control" name="name" id="name">
                                <!--<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>-->
                                <!--    <span class="invalid-feedback" role="alert">-->
                                <!--        <strong><?php echo e($message); ?></strong>-->
                                <!--    </span>-->
                                <!--<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
                                <span class="text-danger" id="err_name" style="color: red!important;"><?php echo e($errors->first('name')); ?></span>
                            </div>
                            <div class="col-md-6">
                                <label>Ratings</label>
                                <input type="text" class="form-control" name="ratings" id="ratings">
                                <!--<?php $__errorArgs = ['ratings'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>-->
                                <!--    <span class="invalid-feedback" role="alert">-->
                                <!--        <strong><?php echo e($message); ?></strong>-->
                                <!--    </span>-->
                                <!--<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
                                <span class="text-danger" id="err_ratings" style="color: red!important;"><?php echo e($errors->first('ratings')); ?></span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label>Total Courses</label>
                                <input type="text" class="form-control" name="total_courses" id="total_courses">
                                <!--<?php $__errorArgs = ['total_courses'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>-->
                                <!--    <span class="invalid-feedback" role="alert">-->
                                <!--        <strong><?php echo e($message); ?></strong>-->
                                <!--    </span>-->
                                <!--<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
                                <span class="text-danger" id="err_total_courses" style="color: red!important;"><?php echo e($errors->first('total_courses')); ?></span>
                            </div>
                            <div class="col-md-6">
                                <label>Image</label>
                                <input type="file" class="form-control" name="image" id="image">
                                <!--<?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>-->
                                <!--    <span class="invalid-feedback" role="alert">-->
                                <!--        <strong><?php echo e($message); ?></strong>-->
                                <!--    </span>-->
                                <!--<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
                                <span class="text-danger" id="err_image" style="color: red!important;"><?php echo e($errors->first('image')); ?></span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <label>Description</label>
                                <textarea class="form-control" rows="4" name="descriptions" id="descriptions"></textarea>
                                <!--<?php $__errorArgs = ['descriptions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>-->
                                <!--    <span class="invalid-feedback" role="alert">-->
                                <!--        <strong><?php echo e(descriptions); ?></strong>-->
                                <!--    </span>-->
                                <!--<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
                                <span class="text-danger" id="err_descriptions" style="color: red!important;"><?php echo e($errors->first('descriptions')); ?></span>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-12">
                                <center><button onclick="formsubmit($(this))" class="btn btn-success" name="submit" type="submit" id="submit"><i class="fas fa-paper-plane"></i> Submit</button>
                                <button class="btn btn-danger" name="reset" type="reset" id="reset"> <i class="fas fa-sync-alt"></i> Reset</button></center>
                            </div>
                        </div>
                        <!--<div class="form-group">-->
                        <!--    <label>Features Name</label>-->
                        <!--    <input type="text" class="form-control" name="name" id="name" value="" readonly>-->
                        <!--</div>-->
                        <!--<div class="form-group">-->
                        <!--    <label>Email</label>-->
                        <!--    <input type="email" class="form-control" name="email" id="email" placeholder="Enter email">-->
                        <!--</div>-->
                        <!--<div class="form-group">-->
                        <!--    <center><button class="btn btn-success" name="submit" type="submit" id="submit"><i class="fas fa-paper-plane"></i> Submit</button>-->
                        <!--    <button class="btn btn-danger" name="reset" type="submit" id="reset"> <i class="fas fa-sync-alt"></i> Reset</button></center>-->
                        <!--</div>-->
                    </form>
                </div>
            </div>
            
            </div>
        </div>
    </div>
    
  <!-- /.content-wrapper -->
  <!--UPDATE Modal -->
    <div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Instructor</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
               <div class="col-md-12">
                    <form method="post" action="javascript:;" id="update_instructor_form" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <label>Instructor Name</label>
                                <input type="text" class="form-control" name="update_name" id="update_name">
                                <input type="hidden" class="form-control"  name="instr_id" id="instr_id">
                                <!--<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>-->
                                <!--    <span class="invalid-feedback" role="alert">-->
                                <!--        <strong><?php echo e($message); ?></strong>-->
                                <!--    </span>-->
                                <!--<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
                                <span class="text-danger" id="update_err_name" style="color: red!important;"><?php echo e($errors->first('update_name')); ?></span>
                            </div>
                            <div class="col-md-6">
                                <label>Ratings</label>
                                <input type="text" class="form-control" name="update_ratings" id="update_ratings">
                                <!--<?php $__errorArgs = ['ratings'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>-->
                                <!--    <span class="invalid-feedback" role="alert">-->
                                <!--        <strong><?php echo e($message); ?></strong>-->
                                <!--    </span>-->
                                <!--<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
                                <span class="text-danger" id="update_err_ratings" style="color: red!important;"><?php echo e($errors->first('update_ratings')); ?></span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label>Total Courses</label>
                                <input type="text" class="form-control" name="update_total_courses" id="update_total_courses">
                                <!--<?php $__errorArgs = ['total_courses'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>-->
                                <!--    <span class="invalid-feedback" role="alert">-->
                                <!--        <strong><?php echo e($message); ?></strong>-->
                                <!--    </span>-->
                                <!--<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
                                <span class="text-danger" id="update_err_total_courses" style="color: red!important;"><?php echo e($errors->first('update_total_courses')); ?></span>
                            </div>
                            <div class="col-md-6">
                                <label>Status</label>
                                <select class="form-control" id="status" name="status">
                                    <option value="1">Active</option>
                                    <option value="0">In-Active</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label>Image</label>
                                <input type="file" class="form-control" name="image" id="image">
                                <!--<?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>-->
                                <!--    <span class="invalid-feedback" role="alert">-->
                                <!--        <strong><?php echo e($message); ?></strong>-->
                                <!--    </span>-->
                                <!--<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
                                <span class="text-danger" id="update_err_image" style="color: red!important;"><?php echo e($errors->first('update_image')); ?></span>
                            </div>
                            <div class="col-md-6">
                                <center><img src="<?php echo e($gst); ?>/" alt="instructor" id="instructor_image" class="img-fluid instructor-img" style="height:60px;width:100px;margin-top: 1.5rem;"></center>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <label>Description</label>
                                <textarea class="form-control" rows="4" name="update_descriptions" id="update_descriptions"></textarea>
                                <!--<?php $__errorArgs = ['descriptions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>-->
                                <!--    <span class="invalid-feedback" role="alert">-->
                                <!--        <strong><?php echo e(descriptions); ?></strong>-->
                                <!--    </span>-->
                                <!--<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
                                <span class="text-danger" id="update_err_descriptions" style="color: red!important;"><?php echo e($errors->first('update_descriptions')); ?></span>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-12">
                                <center><button onclick="update_formsubmit($(this))" class="btn btn-success" name="update_submit" type="submit" id="update_submit"><i class="fas fa-paper-plane"></i> Update</button>
                                <button class="btn btn-danger" name="update_reset" type="reset" id="update_reset"> <i class="fas fa-sync-alt"></i> Reset</button></center>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            </div>
        </div>
    </div>
    
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    //********DATA INSERT ***********
    function formsubmit(e){
        // alert('hg');
        var formData = new FormData($("#add_instructor_form")[0]);
        $.ajax({
            type:'POST',
            url:"<?php echo e(url('save_instructor')); ?>",
            enctype:'multipart/form-data',
            processData:false,
            contentType:false,
            cache:false,
            data:formData,
            dataType: "json",
            success:function(resp){
                //alert(JSON.stringify(resp));
                // var a = JSON.parse('{"error":{"name":"The name field is required.","email":"The email field is required.","password":"The password field is required.","errdt":"Something went wrong"},"outpt":""}');
                var respdat = JSON.parse(JSON.stringify(resp));
                 
                //Name Validation
                if(respdat.error.name){
                    $("#err_name").html(respdat.error.name);
                    $("#err_name").css('display','block');
                    $("#name").css('borderColor','red');
                }else{
                    $("#err_name").css('display','none');
                    $("#name").css('borderColor','green');
                }
                 
                //Image Validation
                if(respdat.error.image){
                    $("#err_image").html(respdat.error.image);
                    $("#err_image").css('display','block');
                    $("#image").css('borderColor','red');
                }else{
                    $("#err_image").css('display','none');
                    $("#image").css('borderColor','green');
                }
                 
                //Ratings Validation
                if(respdat.error.ratings){
                    $("#err_ratings").html(respdat.error.ratings);
                    $("#err_ratings").css('display','block');
                    $("#ratings").css('borderColor','red');
                }else{
                    $("#err_ratings").css('display','none');
                    $("#ratings").css('borderColor','green');
                }
                 
                //Total Courses
                if(respdat.error.total_courses){
                    $("#err_total_courses").html(respdat.error.total_courses);
                    $("#err_total_courses").css('display','block');
                    $("#total_courses").css('borderColor','red');
                }else{
                    $("#err_total_courses").css('display','none');
                    $("#total_courses").css('borderColor','green');
                }
                
                //Description Valiation
                if(respdat.error.descriptions){
                    $("#err_descriptions").html(respdat.error.descriptions);
                    $("#err_descriptions").css('display','block');
                    $("#descriptions").css('borderColor','red');
                }else{
                    $("#err_descriptions").css('display','none');
                    $("#descriptions").css('borderColor','green');
                }
                 
                if(respdat.outpt)
                {
                    window.location.reload();
                }
            }
        });
   }
   //***************DATA FETCH******************
    $(document).on('click', '.edit_id', function(){ 
        var instructor_id = $(this).attr("id");
        var url = "<?php echo e(URL('fetch_instructor')); ?>";
        var getUrl = url+"/"+instructor_id;
        $.ajax({  
            url: getUrl,
			type: "post",
			data:{  _token: '<?php echo csrf_token(); ?>',instructor_id:instructor_id},
            dataType:"json",
            cache: false,
            success:function(data){
                var str = JSON.stringify(data)
                var parsed = JSON.parse(str)[0];
                
                $('#instr_id').val(parsed.id);
                $('#update_name').val(parsed.name);
                $('#update_ratings').val(parsed.ratings);
                $('#update_total_courses').val(parsed.total_courses);
                $('#update_descriptions').html(parsed.descriptions);
                $('#status').val(parsed.status);
                var src1 = $('#instructor_image').prop('src')
                if(src1 == "http://admin.irera.com/images/users/"){
                    var str2 = parsed.image;
                    var res = src1.concat(str2);
                    $("#instructor_image").attr("src", res);
                }else{
                    src1 = "http://admin.irera.com/images/users/";
                    var str2 = parsed.image;
                    var res = src1.concat(str2);
                    $("#instructor_image").attr("src", res);
                }
                $('#updateModal').modal('show');  
            }  
        }); 
       
        $("#image").change(function() {
          readURL(this);
        });
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#instructor_image').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]); // convert to base64 string
            }
        }
    });
    //*************DATA UPDATE*************
    function update_formsubmit(e){
        // alert('hg');
        var formData = new FormData($("#update_instructor_form")[0]);
        $.ajax({
            
            type:'POST',
            url:"<?php echo e(url('update_instructor')); ?>",
            enctype:'multipart/form-data',
            processData:false,
            contentType:false,
            cache:false,
            data:formData,
            dataType: "json",
            success:function(resp){
                //alert(JSON.stringify(resp));
                // var a = JSON.parse('{"error":{"name":"The name field is required.","email":"The email field is required.","password":"The password field is required.","errdt":"Something went wrong"},"outpt":""}');
                var respdat = JSON.parse(JSON.stringify(resp));
                 
                //Name Validation
                if(respdat.error.update_name){
                    $("#update_err_name").html(respdat.error.update_name);
                    $("#update_err_name").css('display','block');
                    $("#update_name").css('borderColor','red');
                }else{
                    $("#update_err_name").css('display','none');
                    $("#update_name").css('borderColor','green');
                }
                 
                //Image Validation
                if(respdat.error.update_image){
                    $("#update_err_image").html(respdat.error.update_image);
                    $("#update_err_image").css('display','block');
                    $("#vimage").css('borderColor','red');
                }else{
                    $("#update_err_image").css('display','none');
                    $("#update_image").css('borderColor','green');
                }
                 
                //Ratings Validation
                if(respdat.error.update_ratings){
                    $("#update_err_ratings").html(respdat.error.update_ratings);
                    $("#update_err_ratings").css('display','block');
                    $("#update_ratings").css('borderColor','red');
                }else{
                    $("#err_ratings").css('display','none');
                    $("#ratings").css('borderColor','green');
                }
                 
                //Total Courses
                if(respdat.error.update_total_courses){
                    $("#update_err_total_courses").html(respdat.error.update_total_courses);
                    $("#err_total_courses").css('display','block');
                    $("#update_total_courses").css('borderColor','red');
                }else{
                    $("#update_err_total_courses").css('display','none');
                    $("#update_total_courses").css('borderColor','green');
                }
                
                //Description Valiation
                if(respdat.error.update_descriptions){
                    $("#update_err_descriptions").html(respdat.error.update_descriptions);
                    $("#update_err_descriptions").css('display','block');
                    $("#update_descriptions").css('borderColor','red');
                }else{
                    $("#update_err_descriptions").css('display','none');
                    $("#update_descriptions").css('borderColor','green');
                }
                 
                if(respdat.outpt)
                {
                    window.location.reload();
                }
            }
        });
   }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/irera/public_html/admin.irera/resources/views/users/instructor.blade.php ENDPATH**/ ?>