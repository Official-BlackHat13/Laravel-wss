
<?php $__env->startSection('content'); ?>
<div class="main-content">
   <div class="section__content section__content--p30">
      <div class="container-fluid">
         <div class="row">
            <div class="col-lg-12">
               <div class="card">
                  <div class="card-header">Edit Coupon</div>
                  <form method="post" action="<?php echo e(route('updatecoupons')); ?>"  enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>
                     <div class="card-body">
                        <div class="row">
                           <div class="col-md-6">
                              <label>Coupon Code:</label>
                              <input type="text" class="form-control" name="coupon_code" value="<?php echo e($editcoupons->coupon_code); ?>">
                              <input type="hidden" class="form-control m-input" name="id" value="<?php echo e($editcoupons->id); ?>">
                           </div>
                        
                           <div class="col-md-6">
                              <label>Expiry Date:</label>
                              <input type="date" class="form-control" name="expiry_date" value="<?php echo e($editcoupons->expiry_date); ?>">
                           </div>
                        </div>
                        <br>
                        <div class="row">
                           <div class="col-md-6">
                              <label>Discount Type:</label>
                              <select class="form-control" name="discount_type">
                                    <option value="%" <?php if($editcoupons->discount_type == '%'){echo 'selected';} ?>>In %</option>
                                    <option value="Fixed" <?php if($editcoupons->discount_type == 'Fixed'){echo 'selected';} ?>>Fixed Amount</option>
                              </select>
                           </div>
                        
                           <div class="col-md-6">
                              <label>Discount Amount:</label>
                              <input type="text" class="form-control" name="discount_amount" value="<?php echo e($editcoupons->discount_amount); ?>">
                           </div>
                        </div>
                        <br>
                        <div class="row">
                           <div class="col-md-6">
                              <label>Maximum Discount:</label>
                              <input type="number" class="form-control" name="max_discount" value="<?php echo e($editcoupons->max_discount); ?>">
                           </div>
                        
                           <div class="col-md-6">
                              <label>Minimum Subtotal:</label>
                               <input type="number" class="form-control" name="min_subtotal" value="<?php echo e($editcoupons->min_subtotal); ?>">
                           </div>
                        </div>
                        <br>
                     </div>
                     <div class="card-footer">
                        <button type="submit" class="btn btn-primary btn-sm">
                        <i class="fa fa-dot-circle-o"></i> Submit
                        </button>
                        <button type="reset" class="btn btn-danger btn-sm">
                        <i class="fa fa-ban"></i> Reset
                        </button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bniindiastore/public_html/bmongers/resources/views/coupons_form_edit.blade.php ENDPATH**/ ?>