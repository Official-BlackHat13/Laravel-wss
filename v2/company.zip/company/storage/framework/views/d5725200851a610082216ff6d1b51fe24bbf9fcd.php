
<?php $__env->startSection('content'); ?>
<div class="main-content">
   <div class="section__content section__content--p30">
      <div class="container-fluid">
         <div class="row">
            <div class="col-lg-12">
               <div class="card">
                  <div class="card-header">Edit Brand Admin</div>
                  <form method="post" action="<?php echo e(route('update-brand-admin')); ?>"  enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>
                     <div class="card-body">
                        <div class="row">
                           <div class="col-md-6">
                              <label>Name:</label>
                              <input type="hidden" class="form-control m-input" name="id" value="<?php echo e($edituser->id); ?>">
                              <input type="text" class="form-control" name="name" value="<?php echo e($edituser->name); ?>">
                           </div>
                        
                           <div class="col-md-6">
                              <label>Email:</label>
                              <input type="text" class="form-control" name="email" value="<?php echo e($edituser->email); ?>">
                           </div>
                        </div>
                        <br>
                        <div class="row">
                           <div class="col-md-6">
                              <label>Mobile:</label>
                              <input type="number" class="form-control" name="phone" value="<?php echo e($edituser->phone); ?>">
                           </div>
                        
                           <div class="col-md-6">
                              <label>Age:</label>
                              <input type="text" class="form-control" name="age" value="<?php echo e($edituser->age); ?>">
                           </div>
                        </div>
                        <br>
                        <div class="row">
                           <div class="col-md-6">
                               <label>Gender:</label>
                              <select class="form-control" name="gender">
                                    <option value="M" <?php if($edituser->gender == 'M'){echo 'selected';} ?>>Male</option>
                                    <option value="F" <?php if($edituser->gender == 'F'){echo 'selected';} ?>>Female</option>
                              </select>
                           </div>
                           <div class="col-md-6">
                              <label>State:</label>
                              <input type="text" class="form-control" name="state" value="<?php echo e($edituser->state); ?>">
                           </div>
                        </div>
                        <br>
                        <div class="row">
                           <div class="col-md-6">
                               <label>City:</label>
                              <select class="form-control" name="city">
                                <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cities->city); ?>" <?php if($edituser->city == $cities->city){echo 'selected';} ?>><?php echo e($cities->city); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                           </div>
                           <div class="col-md-6">
                              <label>Pincode Managed:</label>
                             <select class="form-control js-example-basic-multiple" name="pincode[]" multiple>
                                <?php $__currentLoopData = $dis_explodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>             
                                    <option value="<?php echo e($dis); ?>" selected><?php echo e($dis); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $pin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pins): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pins->pincode); ?>"><?php echo e($pins->pincode); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                           </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-6">
                              <label>Position:</label>
                              <input type="text" name="position" class="form-control" value="<?php echo e($edituser->position); ?>">
                            </div>
                            <!--<div class="col-md-6">-->
                            <!--  <label>Password:</label>-->
                            <!--  <input type="password" name="password" class="form-control" value="<?php echo e($edituser->password); ?>" disabled>-->
                            <!--</div>-->
                        </div>
                     </div>
                     <div class="card-footer">
                        <button type="submit" class="btn btn-primary btn-sm">
                        <i class="fa fa-dot-circle-o"></i> Submit
                        </button>
                        <button type="reset" class="btn btn-danger btn-sm">
                        <i class="fa fa-ban"></i> Reset
                        </button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bniindiastore/public_html/bmongers/resources/views/brand_admin_form_edit.blade.php ENDPATH**/ ?>